// src/main/java/com/docweaver/domain/DocumentType.java
package com.docweaver.domain;

public enum DocumentType {
    INVOICE,
    RECEIPT,
    PURCHASE_ORDER,
    CONTRACT
}
