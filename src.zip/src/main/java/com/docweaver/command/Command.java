// src/main/java/com/docweaver/command/Command.java
package com.docweaver.command;

public interface Command {
    void execute();
}
